import requests
import json
class Pembeli:
    def __init__(self):
        self.__id=None
        self.__id_pembeli = None
        self.__nama_pembeli = None
        self.__usia_pembeli = None
        self.__url = "http://localhost/apppesawat/pembeli_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def id_pembeli(self):
        return self.__id_pembeli
        
    @id_pembeli.setter
    def id_pembeli(self, value):
        self.__id_pembeli = value
    @property
    def nama_pembeli(self):
        return self.__nama_pembeli
        
    @nama_pembeli.setter
    def nama_pembeli(self, value):
        self.__nama_pembeli = value
    @property
    def usia_pembeli(self):
        return self.__usia_pembeli
        
    @usia_pembeli.setter
    def usia_pembeli(self, value):
        self.__usia_pembeli = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_id_pembeli(self, id_pembeli):
        url = self.__url+"?id_pembeli="+id_pembeli
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__id_pembeli = item['id_pembeli']
            self.__nama_pembeli = item['nama_pembeli']
            self.__usia_pembeli = item['usia_pembeli']
        return data
    def simpan(self):
        payload = {
            "id_pembeli":self.__id_pembeli,
            "nama_pembeli":self.__nama_pembeli,
            "usia_pembeli":self.__usia_pembeli
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_id_pembeli(self, id_pembeli):
        url = self.__url+"?id_pembeli="+id_pembeli
        payload = {
            "id_pembeli":self.__id_pembeli,
            "nama_pembeli":self.__nama_pembeli,
            "usia_pembeli":self.__usia_pembeli
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_id_pembeli(self,id_pembeli):
        url = self.__url+"?id_pembeli="+id_pembeli
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
