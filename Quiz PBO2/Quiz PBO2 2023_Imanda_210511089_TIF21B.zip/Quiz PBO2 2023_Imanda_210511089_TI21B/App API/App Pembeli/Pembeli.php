<?php
require_once 'database.php';
class Pembeli 
{
    private $db;
    private $table = 'pembeli';
    public $id_pembeli = "";
    public $nama_pembeli = "";
    public $usia_pembeli = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_id_pembeli(int $id_pembeli)
    {
        $query = "SELECT * FROM $this->table WHERE id_pembeli = $id_pembeli";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`id_pembeli`,`nama_pembeli`,`usia_pembeli`) VALUES ('$this->id_pembeli','$this->nama_pembeli','$this->usia_pembeli')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET id_pembeli = '$this->id_pembeli', nama_pembeli = '$this->nama_pembeli', usia_pembeli = '$this->usia_pembeli' 
        WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_id_pembeli($id_pembeli): int
    {
        $query = "UPDATE $this->table SET id_pembeli = '$this->id_pembeli', nama_pembeli = '$this->nama_pembeli', usia_pembeli = '$this->usia_pembeli' 
        WHERE id_pembeli = $id_pembeli";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_id_pembeli($id_pembeli): int
    {
        $query = "DELETE FROM $this->table WHERE id_pembeli = $id_pembeli";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>