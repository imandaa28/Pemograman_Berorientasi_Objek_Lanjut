import requests
import json
class Rute:
    def __init__(self):
        self.__id=None
        self.__kode_rute = None
        self.__rute = None
        self.__kelas = None
        self.__harga = None
        self.__waktu = None
        self.__url = "http://localhost/apppesawat/rute_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kode_rute(self):
        return self.__kode_rute
        
    @kode_rute.setter
    def kode_rute(self, value):
        self.__kode_rute = value
    @property
    def rute(self):
        return self.__rute
        
    @rute.setter
    def rute(self, value):
        self.__rute = value
    @property
    def kelas(self):
        return self.__kelas
        
    @kelas.setter
    def kelas(self, value):
        self.__kelas = value
    @property
    def harga(self):
        return self.__harga
        
    @harga.setter
    def harga(self, value):
        self.__harga = value
    @property
    def waktu(self):
        return self.__waktu
        
    @waktu.setter
    def waktu(self, value):
        self.__waktu = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kode_rute(self, kode_rute):
        url = self.__url+"?kode_rute="+kode_rute
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__kode_rute = item['kode_rute']
            self.__rute = item['rute']
            self.__kelas = item['kelas']
            self.__harga = item['harga']
            self.__waktu = item['waktu']
        return data
    def simpan(self):
        payload = {
            "kode_rute":self.__kode_rute,
            "rute":self.__rute,
            "kelas":self.__kelas,
            "harga":self.__harga,
            "waktu":self.__waktu
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kode_rute(self, kode_rute):
        url = self.__url+"?kode_rute="+kode_rute
        payload = {
            "kode_rute":self.__kode_rute,
            "rute":self.__rute,
            "kelas":self.__kelas,
            "harga":self.__harga,
            "waktu":self.__waktu
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kode_rute(self,kode_rute):
        url = self.__url+"?kode_rute="+kode_rute
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
