<?php
require_once 'database.php';
class Rute 
{
    private $db;
    private $table = 'rute';
    public $kode_rute = "";
    public $rute = "";
    public $kelas = "";
    public $harga = "";
    public $waktu = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_kode_rute(int $kode_rute)
    {
        $query = "SELECT * FROM $this->table WHERE kode_rute = $kode_rute";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kode_rute`,`rute`,`kelas`,`harga`,`waktu`) VALUES ('$this->kode_rute','$this->rute','$this->kelas','$this->harga','$this->waktu')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET kode_rute = '$this->kode_rute', rute = '$this->rute', kelas = '$this->kelas', harga = '$this->harga', waktu = '$this->waktu' 
        WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_kode_rute($kode_rute): int
    {
        $query = "UPDATE $this->table SET kode_rute = '$this->kode_rute', rute = '$this->rute', kelas = '$this->kelas', harga = '$this->harga', waktu = '$this->waktu' 
        WHERE kode_rute = $kode_rute";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_kode_rute($kode_rute): int
    {
        $query = "DELETE FROM $this->table WHERE kode_rute = $kode_rute";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>