import requests
import json
class Pesawat:
    def __init__(self):
        self.__id=None
        self.__kode_pesawat = None
        self.__nama_pesawat = None
        self.__nomor_kursi = None
        self.__url = "http://localhost/apppesawat/pesawat_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kode_pesawat(self):
        return self.__kode_pesawat
        
    @kode_pesawat.setter
    def kode_pesawat(self, value):
        self.__kode_pesawat = value
    @property
    def nama_pesawat(self):
        return self.__nama_pesawat
        
    @nama_pesawat.setter
    def nama_pesawat(self, value):
        self.__nama_pesawat = value
    @property
    def nomor_kursi(self):
        return self.__nomor_kursi
        
    @nomor_kursi.setter
    def nomor_kursi(self, value):
        self.__nomor_kursi = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kode_pesawat(self, kode_pesawat):
        url = self.__url+"?kode_pesawat="+kode_pesawat
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__kode_pesawat = item['kode_pesawat']
            self.__nama_pesawat = item['nama_pesawat']
            self.__nomor_kursi = item['nomor_kursi']
        return data
    def simpan(self):
        payload = {
            "kode_pesawat":self.__kode_pesawat,
            "nama_pesawat":self.__nama_pesawat,
            "nomor_kursi":self.__nomor_kursi
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kode_pesawat(self, kode_pesawat):
        url = self.__url+"?kode_pesawat="+kode_pesawat
        payload = {
            "kode_pesawat":self.__kode_pesawat,
            "nama_pesawat":self.__nama_pesawat,
            "nomor_kursi":self.__nomor_kursi
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kode_pesawat(self,kode_pesawat):
        url = self.__url+"?kode_pesawat="+kode_pesawat
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
