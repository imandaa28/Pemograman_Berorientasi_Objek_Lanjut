import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Pesawat import *
class FrmPesawat:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("450x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='KODE_PESAWAT:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='NAMA_PESAWAT:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='NOMOR_KURSI:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtKode_pesawat = Entry(mainFrame) 
        self.txtKode_pesawat.grid(row=0, column=1, padx=5, pady=5)
        self.txtKode_pesawat.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtNama_pesawat = Entry(mainFrame) 
        self.txtNama_pesawat.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtNomor_kursi = Entry(mainFrame) 
        self.txtNomor_kursi.grid(row=2, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('id','kode_pesawat','nama_pesawat','nomor_kursi')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id', text='ID')
        self.tree.column('id', width="30")
        self.tree.heading('kode_pesawat', text='KODE_PESAWAT')
        self.tree.column('kode_pesawat', width="120")
        self.tree.heading('nama_pesawat', text='NAMA_PESAWAT')
        self.tree.column('nama_pesawat', width="120")
        self.tree.heading('nomor_kursi', text='NOMOR_KURSI')
        self.tree.column('nomor_kursi', width="120")
        # set tree position
        self.tree.place(x=0, y=200)
        
    def onClear(self, event=None):
        self.txtKode_pesawat.delete(0,END)
        self.txtKode_pesawat.insert(END,"")
        self.txtNama_pesawat.delete(0,END)
        self.txtNama_pesawat.insert(END,"")
        self.txtNomor_kursi.delete(0,END)
        self.txtNomor_kursi.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data pesawat
        obj = Pesawat()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["kode_pesawat"],d["nama_pesawat"],d["nomor_kursi"]))
    def onCari(self, event=None):
        kode_pesawat = self.txtKode_pesawat.get()
        obj = Pesawat()
        a = obj.get_by_kode_pesawat(kode_pesawat)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        kode_pesawat = self.txtKode_pesawat.get()
        obj = Pesawat()
        res = obj.get_by_kode_pesawat(kode_pesawat)
        self.txtKode_pesawat.delete(0,END)
        self.txtKode_pesawat.insert(END,obj.kode_pesawat)
        self.txtNama_pesawat.delete(0,END)
        self.txtNama_pesawat.insert(END,obj.nama_pesawat)
        self.txtNomor_kursi.delete(0,END)
        self.txtNomor_kursi.insert(END,obj.nomor_kursi)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        kode_pesawat = self.txtKode_pesawat.get()
        nama_pesawat = self.txtNama_pesawat.get()
        nomor_kursi = self.txtNomor_kursi.get()
        # create new Object
        obj = Pesawat()
        obj.kode_pesawat = kode_pesawat
        obj.nama_pesawat = nama_pesawat
        obj.nomor_kursi = nomor_kursi
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kode_pesawat(kode_pesawat)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        kode_pesawat = self.txtKode_pesawat.get()
        obj = Pesawat()
        obj.kode_pesawat = kode_pesawat
        if(self.ditemukan==True):
            res = obj.delete_by_kode_pesawat(kode_pesawat)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmPesawat(root2, "Aplikasi Data Pesawat")
    root2.mainloop()
