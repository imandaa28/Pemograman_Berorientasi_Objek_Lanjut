import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Pemesanan import *
class FrmPemesanan:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("720x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='ID_PEMBELI:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='KODE_RUTE:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='KODE_PESAWAT:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='TANGGAL_BERANGKAT:').grid(row=3, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='WAKTU_BERANGKAT:').grid(row=4, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='WAKTU_SAMPAI:').grid(row=5, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtId_pembeli = Entry(mainFrame) 
        self.txtId_pembeli.grid(row=0, column=1, padx=5, pady=5)
        self.txtId_pembeli.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtKode_rute = Entry(mainFrame) 
        self.txtKode_rute.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtKode_pesawat = Entry(mainFrame) 
        self.txtKode_pesawat.grid(row=2, column=1, padx=5, pady=5)
        # Textbox
        self.txtTanggal_berangkat = Entry(mainFrame) 
        self.txtTanggal_berangkat.grid(row=3, column=1, padx=5, pady=5)
        # Textbox
        self.txtWaktu_berangkat = Entry(mainFrame) 
        self.txtWaktu_berangkat.grid(row=4, column=1, padx=5, pady=5)
        # Textbox
        self.txtWaktu_sampai = Entry(mainFrame) 
        self.txtWaktu_sampai.grid(row=5, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('id','id_pembeli','kode_rute','kode_pesawat','tanggal_berangkat','waktu_berangkat','waktu_sampai')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id', text='ID')
        self.tree.column('id', width="30")
        self.tree.heading('id_pembeli', text='ID_PEMBELI')
        self.tree.column('id_pembeli', width=" 100")
        self.tree.heading('kode_rute', text='KODE_RUTE')
        self.tree.column('kode_rute', width="80")
        self.tree.heading('kode_pesawat', text='KODE_PESAWAT')
        self.tree.column('kode_pesawat', width="110")
        self.tree.heading('tanggal_berangkat', text='TANGGAL_BERANGKAT')
        self.tree.column('tanggal_berangkat', width="135")
        self.tree.heading('waktu_berangkat', text='WAKTU_BERANGKAT')
        self.tree.column('waktu_berangkat', width="120")
        self.tree.heading('waktu_sampai', text='WAKTU_SAMPAI')
        self.tree.column('waktu_sampai', width="120")
        # set tree position
        self.tree.place(x=0, y=200)
        
    def onClear(self, event=None):
        self.txtId_pembeli.delete(0,END)
        self.txtId_pembeli.insert(END,"")
        self.txtKode_rute.delete(0,END)
        self.txtKode_rute.insert(END,"")
        self.txtKode_pesawat.delete(0,END)
        self.txtKode_pesawat.insert(END,"")
        self.txtTanggal_berangkat.delete(0,END)
        self.txtTanggal_berangkat.insert(END,"")
        self.txtWaktu_berangkat.delete(0,END)
        self.txtWaktu_berangkat.insert(END,"")
        self.txtWaktu_sampai.delete(0,END)
        self.txtWaktu_sampai.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data pemesanan
        obj = Pemesanan()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["id_pembeli"],d["kode_rute"],d["kode_pesawat"],d["tanggal_berangkat"],d["waktu_berangkat"],d["waktu_sampai"]))
    def onCari(self, event=None):
        id_pembeli = self.txtId_pembeli.get()
        obj = Pemesanan()
        a = obj.get_by_id_pembeli(id_pembeli)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        id_pembeli = self.txtId_pembeli.get()
        obj = Pemesanan()
        res = obj.get_by_id_pembeli(id_pembeli)
        self.txtId_pembeli.delete(0,END)
        self.txtId_pembeli.insert(END,obj.id_pembeli)
        self.txtKode_rute.delete(0,END)
        self.txtKode_rute.insert(END,obj.kode_rute)
        self.txtKode_pesawat.delete(0,END)
        self.txtKode_pesawat.insert(END,obj.kode_pesawat)
        self.txtTanggal_berangkat.delete(0,END)
        self.txtTanggal_berangkat.insert(END,obj.tanggal_berangkat)
        self.txtWaktu_berangkat.delete(0,END)
        self.txtWaktu_berangkat.insert(END,obj.waktu_berangkat)
        self.txtWaktu_sampai.delete(0,END)
        self.txtWaktu_sampai.insert(END,obj.waktu_sampai)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        id_pembeli = self.txtId_pembeli.get()
        kode_rute = self.txtKode_rute.get()
        kode_pesawat = self.txtKode_pesawat.get()
        tanggal_berangkat = self.txtTanggal_berangkat.get()
        waktu_berangkat = self.txtWaktu_berangkat.get()
        waktu_sampai = self.txtWaktu_sampai.get()
        # create new Object
        obj = Pemesanan()
        obj.id_pembeli = id_pembeli
        obj.kode_rute = kode_rute
        obj.kode_pesawat = kode_pesawat
        obj.tanggal_berangkat = tanggal_berangkat
        obj.waktu_berangkat = waktu_berangkat
        obj.waktu_sampai = waktu_sampai
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_id_pembeli(id_pembeli)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        id_pembeli = self.txtId_pembeli.get()
        obj = Pemesanan()
        obj.id_pembeli = id_pembeli
        if(self.ditemukan==True):
            res = obj.delete_by_id_pembeli(id_pembeli)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmPemesanan(root2, "Aplikasi Data Pemesanan")
    root2.mainloop()
