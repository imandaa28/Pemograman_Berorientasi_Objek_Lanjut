<?php
require_once 'database.php';
require_once 'Pemesanan.php';
$db = new MySQLDatabase();
$pemesanan = new Pemesanan($db);
$id=0;
$id_pembeli=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['id_pembeli'])){
            $id_pembeli = $_GET['id_pembeli'];
        }
        if($id>0){    
            $result = $pemesanan->get_by_id($id);
        }elseif($id_pembeli>0){
            $result = $pemesanan->get_by_id_pembeli($id_pembeli);
        } else {
            $result = $pemesanan->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new pemesanan
        $pemesanan->id_pembeli = $_POST['id_pembeli'];
        $pemesanan->kode_rute = $_POST['kode_rute'];
        $pemesanan->kode_pesawat = $_POST['kode_pesawat'];
        $pemesanan->tanggal_berangkat = $_POST['tanggal_berangkat'];
        $pemesanan->waktu_berangkat = $_POST['waktu_berangkat'];
        $pemesanan->waktu_sampai = $_POST['waktu_sampai'];
       
        $pemesanan->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Pemesanan created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Pemesanan not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['id_pembeli'])){
            $id_pembeli = $_GET['id_pembeli'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $pemesanan->id_pembeli = $_PUT['id_pembeli'];
        $pemesanan->kode_rute = $_PUT['kode_rute'];
        $pemesanan->kode_pesawat = $_PUT['kode_pesawat'];
        $pemesanan->tanggal_berangkat = $_PUT['tanggal_berangkat'];
        $pemesanan->waktu_berangkat = $_PUT['waktu_berangkat'];
        $pemesanan->waktu_sampai = $_PUT['waktu_sampai'];
        if($id>0){    
            $pemesanan->update($id);
        }elseif($id_pembeli<>""){
            $pemesanan->update_by_id_pembeli($id_pembeli);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Pemesanan updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Pemesanan update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['id_pembeli'])){
            $id_pembeli = $_GET['id_pembeli'];
        }
        if($id>0){    
            $pemesanan->delete($id);
        }elseif($id_pembeli>0){
            $pemesanan->delete_by_id_pembeli($id_pembeli);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Pemesanan deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Pemesanan delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>