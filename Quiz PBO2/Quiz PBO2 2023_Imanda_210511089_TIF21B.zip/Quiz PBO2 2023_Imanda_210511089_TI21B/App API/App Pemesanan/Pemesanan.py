import requests
import json
class Pemesanan:
    def __init__(self):
        self.__id=None
        self.__id_pembeli = None
        self.__kode_rute = None
        self.__kode_pesawat = None
        self.__tanggal_berangkat = None
        self.__waktu_berangkat = None
        self.__waktu_sampai = None
        self.__url = "http://localhost/apppesawat/pemesanan_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def id_pembeli(self):
        return self.__id_pembeli
        
    @id_pembeli.setter
    def id_pembeli(self, value):
        self.__id_pembeli = value
    @property
    def kode_rute(self):
        return self.__kode_rute
        
    @kode_rute.setter
    def kode_rute(self, value):
        self.__kode_rute = value
    @property
    def kode_pesawat(self):
        return self.__kode_pesawat
        
    @kode_pesawat.setter
    def kode_pesawat(self, value):
        self.__kode_pesawat = value
    @property
    def tanggal_berangkat(self):
        return self.__tanggal_berangkat
        
    @tanggal_berangkat.setter
    def tanggal_berangkat(self, value):
        self.__tanggal_berangkat = value
    @property
    def waktu_berangkat(self):
        return self.__waktu_berangkat
        
    @waktu_berangkat.setter
    def waktu_berangkat(self, value):
        self.__waktu_berangkat = value
    @property
    def waktu_sampai(self):
        return self.__waktu_sampai
        
    @waktu_sampai.setter
    def waktu_sampai(self, value):
        self.__waktu_sampai = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_id_pembeli(self, id_pembeli):
        url = self.__url+"?id_pembeli="+id_pembeli
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__id_pembeli = item['id_pembeli']
            self.__kode_rute = item['kode_rute']
            self.__kode_pesawat = item['kode_pesawat']
            self.__tanggal_berangkat = item['tanggal_berangkat']
            self.__waktu_berangkat = item['waktu_berangkat']
            self.__waktu_sampai = item['waktu_sampai']
        return data
    def simpan(self):
        payload = {
            "id_pembeli":self.__id_pembeli,
            "kode_rute":self.__kode_rute,
            "kode_pesawat":self.__kode_pesawat,
            "tanggal_berangkat":self.__tanggal_berangkat,
            "waktu_berangkat":self.__waktu_berangkat,
            "waktu_sampai":self.__waktu_sampai
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_id_pembeli(self, id_pembeli):
        url = self.__url+"?id_pembeli="+id_pembeli
        payload = {
            "id_pembeli":self.__id_pembeli,
            "kode_rute":self.__kode_rute,
            "kode_pesawat":self.__kode_pesawat,
            "tanggal_berangkat":self.__tanggal_berangkat,
            "waktu_berangkat":self.__waktu_berangkat,
            "waktu_sampai":self.__waktu_sampai
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_id_pembeli(self,id_pembeli):
        url = self.__url+"?id_pembeli="+id_pembeli
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
