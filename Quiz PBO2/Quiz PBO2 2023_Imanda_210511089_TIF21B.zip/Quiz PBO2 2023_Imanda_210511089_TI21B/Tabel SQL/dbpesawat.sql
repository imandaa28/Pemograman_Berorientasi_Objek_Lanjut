-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2023 at 04:17 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbpesawat`
--

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `id` int(11) NOT NULL,
  `id_pembeli` varchar(20) NOT NULL,
  `nama_pembeli` varchar(40) NOT NULL,
  `usia_pembeli` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`id`, `id_pembeli`, `nama_pembeli`, `usia_pembeli`) VALUES
(1, 'AQZ987362', 'Imanda', 22),
(2, 'AQZ987667', 'Alex Bhizer', 21),
(3, 'AQZ009456', 'Juan Dadali', 30),
(4, 'AQZ018772', 'Abdurohman', 33);

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE `pemesanan` (
  `id` int(11) NOT NULL,
  `id_pembeli` varchar(20) NOT NULL,
  `kode_rute` varchar(5) NOT NULL,
  `kode_pesawat` varchar(15) NOT NULL,
  `tanggal_berangkat` varchar(10) NOT NULL,
  `waktu_berangkat` varchar(10) NOT NULL,
  `waktu_sampai` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`id`, `id_pembeli`, `kode_rute`, `kode_pesawat`, `tanggal_berangkat`, `waktu_berangkat`, `waktu_sampai`) VALUES
(1, 'AQZ987362', 'BGR', '111712', '01-07-2023', '17.00', '19.00'),
(2, 'AQZ987667', 'BKS', '111713', '02-07-2023', '18.00', '22.00'),
(3, 'AQZ009456', 'JKT', '111714', '05-07-2023', '06.00', '10.00'),
(4, 'AQZ018772', 'PKL', '111715', '10-07-2023', '14.00', '16.00');

-- --------------------------------------------------------

--
-- Table structure for table `pesawat`
--

CREATE TABLE `pesawat` (
  `id` int(11) NOT NULL,
  `kode_pesawat` int(15) NOT NULL,
  `nama_pesawat` varchar(20) NOT NULL,
  `nomor_kursi` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pesawat`
--

INSERT INTO `pesawat` (`id`, `kode_pesawat`, `nama_pesawat`, `nomor_kursi`) VALUES
(1, 111712, 'Batik Air', 'B12'),
(2, 111713, 'Garuda Indonesia', 'B13'),
(3, 111714, 'Lion Air', 'B14'),
(4, 111715, 'Air Asia', 'B15');

-- --------------------------------------------------------

--
-- Table structure for table `rute`
--

CREATE TABLE `rute` (
  `id` int(11) NOT NULL,
  `kode_rute` varchar(11) NOT NULL,
  `rute` varchar(11) NOT NULL,
  `kelas` varchar(11) NOT NULL,
  `harga` varchar(15) NOT NULL,
  `waktu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rute`
--

INSERT INTO `rute` (`id`, `kode_rute`, `rute`, `kelas`, `harga`, `waktu`) VALUES
(1, 'BGR', 'Bogor', 'C', 'Rp 900.000', 2),
(2, 'BKS', 'Bekasi', 'F', 'Rp 600.000', 4),
(3, 'JKT', 'Jakarta', 'Y', 'Rp 1.500.000', 1),
(4, 'PKL', 'Pekalongan', 'C', 'Rp 900.000', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `rolename` enum('admin','dosen','mahasiswa') NOT NULL DEFAULT 'mahasiswa'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `passwd`, `rolename`) VALUES
(1, 'tatang', '202cb962ac59075b964b07152d234b70', 'admin'),
(2, 'sokid', '202cb962ac59075b964b07152d234b70', 'dosen'),
(3, 'farhan', '202cb962ac59075b964b07152d234b70', 'mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_pembeli` (`id_pembeli`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_pembeli` (`id_pembeli`);

--
-- Indexes for table `pesawat`
--
ALTER TABLE `pesawat`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_pesawat` (`kode_pesawat`);

--
-- Indexes for table `rute`
--
ALTER TABLE `rute`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_rute` (`kode_rute`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pembeli`
--
ALTER TABLE `pembeli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pesawat`
--
ALTER TABLE `pesawat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rute`
--
ALTER TABLE `rute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
