import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Rute import *
class FrmRute:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("450x435")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='KODE RUTE :').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='RUTE :').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='KELAS :').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='HARGA :').grid(row=3, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='WAKTU:').grid(row=4, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtKode_rute = Entry(mainFrame) 
        self.txtKode_rute.grid(row=0, column=1, padx=5, pady=5)
        self.txtKode_rute.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtRute = Entry(mainFrame) 
        self.txtRute.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtKelas = Entry(mainFrame) 
        self.txtKelas.grid(row=2, column=1, padx=5, pady=5)
        # Textbox
        self.txtHarga = Entry(mainFrame) 
        self.txtHarga.grid(row=3, column=1, padx=5, pady=5)
        # Textbox
        self.txtWaktu = Entry(mainFrame) 
        self.txtWaktu.grid(row=4, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('id','kode_rute','rute','kelas','harga','waktu')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id', text='ID')
        self.tree.column('id', width="30")
        self.tree.heading('kode_rute', text='Kode Rute')
        self.tree.column('kode_rute', width="100")
        self.tree.heading('rute', text='Rute')
        self.tree.column('rute', width="90")
        self.tree.heading('kelas', text='Kelas')
        self.tree.column('kelas', width="50")
        self.tree.heading('harga', text='Harga')
        self.tree.column('harga', width="100")
        self.tree.heading('waktu', text='Waktu')
        self.tree.column('waktu', width="60")
        # set tree position
        self.tree.place(x=0, y=180)
        
    def onClear(self, event=None):
        self.txtKode_rute.delete(0,END)
        self.txtKode_rute.insert(END,"")
        self.txtRute.delete(0,END)
        self.txtRute.insert(END,"")
        self.txtKelas.delete(0,END)
        self.txtKelas.insert(END,"")
        self.txtHarga.delete(0,END)
        self.txtHarga.insert(END,"")
        self.txtWaktu.delete(0,END)
        self.txtWaktu.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data rute
        obj = Rute()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["kode_rute"],d["rute"],d["kelas"],d["harga"],d["waktu"]))
    def onCari(self, event=None):
        kode_rute = self.txtKode_rute.get()
        obj = Rute()
        a = obj.get_by_kode_rute(kode_rute)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        kode_rute = self.txtKode_rute.get()
        obj = Rute()
        res = obj.get_by_kode_rute(kode_rute)
        self.txtKode_rute.delete(0,END)
        self.txtKode_rute.insert(END,obj.kode_rute)
        self.txtRute.delete(0,END)
        self.txtRute.insert(END,obj.rute)
        self.txtKelas.delete(0,END)
        self.txtKelas.insert(END,obj.kelas)
        self.txtHarga.delete(0,END)
        self.txtHarga.insert(END,obj.harga)
        self.txtWaktu.delete(0,END)
        self.txtWaktu.insert(END,obj.waktu)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        kode_rute = self.txtKode_rute.get()
        rute = self.txtRute.get()
        kelas = self.txtKelas.get()
        harga = self.txtHarga.get()
        waktu = self.txtWaktu.get()
        # create new Object
        obj = Rute()
        obj.kode_rute = kode_rute
        obj.rute = rute
        obj.kelas = kelas
        obj.harga = harga
        obj.waktu = waktu
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kode_rute(kode_rute)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        kode_rute = self.txtKode_rute.get()
        obj = Rute()
        obj.kode_rute = kode_rute
        if(self.ditemukan==True):
            res = obj.delete_by_kode_rute(kode_rute)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmRute(root2, "Aplikasi Data Rute")
    root2.mainloop()
